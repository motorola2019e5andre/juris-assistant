// Abrir side panel quando clicar no ícone
chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ tabId: tab.id });
});

// Opcional: abrir side panel automaticamente em sites de tribunal
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    const tribunais = ['pje.tst.jus.br', 'pje.trt', 'trt', 'pje'];
    if (tribunais.some(t => tab.url.includes(t))) {
      await chrome.sidePanel.open({ tabId: tabId });
    }
  }
});

// Lista de tribunais e seus seletores
const TRIBUNALS = {
  'pje.tst.jus.br': { 
    name: 'TST', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo, .processo-numero',
    movementSelector: '.movimentacao, .movement, .andamento, .timeline'
  },
  'pje.trt1.jus.br': { 
    name: 'TRT 1ª Região (RJ)', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo, .processo-numero',
    movementSelector: '.movimentacao, .movement'
  },
  'pje.trt2.jus.br': { 
    name: 'TRT 2ª Região (SP)', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo',
    movementSelector: '.movimentacao'
  },
  'pje.trt3.jus.br': { 
    name: 'TRT 3ª Região (MG)', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo',
    movementSelector: '.movimentacao'
  },
  'pje.trt4.jus.br': { 
    name: 'TRT 4ª Região (RS)', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo',
    movementSelector: '.movimentacao'
  },
  'pje.trt15.jus.br': { 
    name: 'TRT 15ª Região (SP)', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo',
    movementSelector: '.movimentacao'
  },
  'pje.trt18.jus.br': { 
    name: 'TRT 18ª Região (GO)', 
    loginSelector: '#username, #email',
    processNumberSelector: '.numero-processo',
    movementSelector: '.movimentacao'
  }
};

// Função para extrair dados da página ativa
function extrairDadosDaPagina() {
  const url = window.location.href;
  let tribunalInfo = null;
  
  // Identifica o tribunal
  for (const [domain, info] of Object.entries(TRIBUNALS)) {
    if (url.includes(domain)) {
      tribunalInfo = info;
      break;
    }
  }
  
  if (!tribunalInfo) {
    return { 
      success: false, 
      error: 'Tribunal não reconhecido. Abra um processo em um tribunal PJe.',
      url: url 
    };
  }
  
  // Verifica se está logado
  const userElement = document.querySelector('.usuario-logado, .user-info, [class*="usuario"], .nome-usuario');
  const loginForm = document.querySelector(tribunalInfo.loginSelector);
  const isLoggedIn = userElement !== null || loginForm === null;
  
  // Extrai número do processo
  let processoNumero = null;
  const numSelectors = tribunalInfo.processNumberSelector.split(', ');
  for (const selector of numSelectors) {
    const element = document.querySelector(selector);
    if (element && element.innerText) {
      const text = element.innerText.trim();
      // Regex para número do processo PJe
      const match = text.match(/\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/);
      if (match) {
        processoNumero = match[0];
        break;
      }
      // Tenta outro formato
      const match2 = text.match(/\d{20,25}/);
      if (match2) {
        processoNumero = match2[0];
        break;
      }
    }
  }
  
  // Extrai andamento/movimentação
  let andamento = null;
  const movementSelectors = tribunalInfo.movementSelector.split(', ');
  for (const selector of movementSelectors) {
    const element = document.querySelector(selector);
    if (element && element.innerText.trim().length > 0) {
      andamento = element.innerText;
      break;
    }
  }
  
  // Se não encontrou com os seletores específicos, tenta seletores genéricos
  if (!andamento) {
    const genericSelectors = ['.movimentacao', '.movement', '.andamento', '.historico', '.timeline', '.table tbody'];
    for (const selector of genericSelectors) {
      const element = document.querySelector(selector);
      if (element && element.innerText.trim().length > 50) {
        andamento = element.innerText;
        break;
      }
    }
  }
  
  // Extrai título da página
  let titulo = document.title || '';
  
  return {
    success: true,
    tribunal: tribunalInfo.name,
    url: url,
    isLoggedIn: isLoggedIn,
    processoNumero: processoNumero,
    andamento: andamento,
    titulo: titulo
  };
}

// Listener para mensagens da popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  
  // Verificar status de login
  if (request.action === 'checkLoginStatus') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: extrairDadosDaPagina
        });
        sendResponse(results[0].result);
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    });
    return true;
  }
  
  // Extrair processo (alias para o mesmo)
  if (request.action === 'extractProcess') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: extrairDadosDaPagina
        });
        sendResponse(results[0].result);
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    });
    return true;
  }
  
  // Ler o que está na página atual
  if (request.action === 'readCurrentPage') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          function: extrairDadosDaPagina
        });
        sendResponse(results[0].result);
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    });
    return true;
  }
});